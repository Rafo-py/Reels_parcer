# Instagram Reels Viral Parser Bot (updated)

This update adds a **viral Reels parser** and integrates it into your existing aiogram bot.

## What's new
- `parse_reels.py` — parses a user's Reels with [instaloader], computes viral factor = **views / followers**, and returns the top results.
- `handlers/reels.py` — adds the `/reels` command to your bot.
- `bot.py` — registers the new handler.

## Virality formula
```
virality = views / followers
```
Higher is better. Example: 500k views / 250k followers = **2.0**.

## Commands
```
/reels <username> [limit] [min_ratio]
```
Examples:
- `/reels nasa` → top 5 viral reels
- `/reels nasa 10` → top 10
- `/reels nasa 10 0.5` → top 10 with virality ≥ 0.5

## Setup
1. Fill in your bot token in `config.py` (`TOKEN`).
2. (Recommended) Put Instagram credentials in `config.py`:
   ```python
   INST_LOGIN = "your_username"
   INST_PASS = "your_password"
   ```
   Without login, Instagram may throttle/limit requests.

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Run:
   ```
   python -m insta_parser_bot.bot
   ```

## Notes
- The parser scans up to **~250 recent posts** to keep it fast and avoid rate limits.
- Only **video posts** are considered (Reels are videos). Links are formatted as `https://www.instagram.com/reel/<shortcode>/`.
- If you need CSV export, keep using the existing flow (`parse_posts.py`) — this update doesn't remove anything.